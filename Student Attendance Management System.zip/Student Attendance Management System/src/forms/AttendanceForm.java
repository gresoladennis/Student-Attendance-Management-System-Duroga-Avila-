/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package forms;

import java.sql.*;
import java.time.LocalDate;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.util.Date;


import CRUD.AttendanceData;

/**
 *
 * @author Admin
 */
public class AttendanceForm extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(AttendanceForm.class.getName());

    /**
     * Creates new form NewJFrame
     */
private String role;

    public AttendanceForm(String role) {
        initComponents();
        setTitle("Attendance");
        this.role = role;
        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setResizable(true);
        setLocationRelativeTo(null);

        initAttendanceTables();
        loadClasses();
        loadStatusCombo();
        loadAttendanceTable();
        
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                openDashboard();
            }
        });
    }
    
    private void loadStatusCombo() {
    cmbStatus.removeAllItems();
    cmbStatus.addItem("Select Status");
    cmbStatus.addItem("Present");
    cmbStatus.addItem("Absent");
    cmbStatus.addItem("Late");
    cmbStatus.addItem("Excused");
}

    //ini na method para ini an pagpidlit an X mabalik ha dashboard
    private void openDashboard() {
        Dashboard dash = new Dashboard(role); // CHANGED
        dash.setVisible(true);
        this.dispose();
    }

    private void loadClasses() {
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>();
        model.addElement("Select Class");

        String sql = "SELECT class_id, class_name FROM tbl_classes ORDER BY class_name";

        try (Connection conn = AttendanceData.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                int id = rs.getInt("class_id");
                String name = rs.getString("class_name");
                model.addElement(id + " - " + name);
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading classes: " + ex.getMessage());
        }

        cmbclass.setModel(model);
    }

    
    private int parseClassIdFromCombo() {
        Object sel = cmbclass.getSelectedItem();
        if (sel == null) return -1;

        String s = sel.toString();
        if (!s.contains(" - ")) return -1;

        try {
            return Integer.parseInt(s.split(" - ")[0].trim());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

private void loadEnrolledStudents(int classId) {
        DefaultTableModel model = (DefaultTableModel) tblAttendance.getModel();
        model.setRowCount(0);

        String sql = """
                SELECT e.enrollment_id, s.student_id, s.full_name
                FROM tbl_enrollments e
                JOIN tbl_students s ON e.student_id = s.student_id
                WHERE e.class_id = ?
                ORDER BY s.full_name
                """;

        try (Connection conn = AttendanceData.getConnection();
             PreparedStatement pst = conn.prepareStatement(sql)) {

            pst.setInt(1, classId);

            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("enrollment_id"),
                        rs.getInt("student_id"),
                        rs.getString("full_name"),
                        Boolean.FALSE
                    });
                }
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading students: " + ex.getMessage());
        }
    }

     private void saveAttendanceForSelectedStudents() {
    int classId = parseClassIdFromCombo();
    if (classId < 0) {
        JOptionPane.showMessageDialog(this, "Please select a class first.");
        return;
    }

    String status = (cmbStatus.getSelectedItem() != null)
            ? cmbStatus.getSelectedItem().toString()
            : "";

    if (status.isEmpty() || status.equalsIgnoreCase("Select Status")) {
        JOptionPane.showMessageDialog(this, "Please select a status.");
        return;
    }

    // --- FIX DITO ---
    Date selectedDate = dcAttendanceDate.getDate();
    if (selectedDate == null) {
        JOptionPane.showMessageDialog(this, "Please choose an attendance date.");
        return;
    }
    java.sql.Date sqlDate = new java.sql.Date(selectedDate.getTime());
    // ----------------

    DefaultTableModel model = (DefaultTableModel) tblAttendance.getModel();
    int rows = model.getRowCount();
    boolean anySelected = false;

    String sql = "INSERT INTO tbl_attendance (enrollment_id, attendance_date, status, remarks) " +
            "VALUES (?, ?, ?, ?)";

    try (Connection conn = AttendanceData.getConnection();
         PreparedStatement pst = conn.prepareStatement(sql)) {

        conn.setAutoCommit(false);

        for (int i = 0; i < rows; i++) {
            Boolean checked = (Boolean) model.getValueAt(i, 3);
            if (checked == null || !checked) continue;

            anySelected = true;

            int enrollId = Integer.parseInt(model.getValueAt(i, 0).toString());
            pst.setInt(1, enrollId);

            // --- FIX DITO: gamitin ang napiling date ---
            pst.setDate(2, sqlDate);

            pst.setString(3, status);
            pst.setString(4, txtRemarks.getText() == null ? "" : txtRemarks.getText());
            pst.addBatch();
        }

        if (!anySelected) {
            JOptionPane.showMessageDialog(this, "No students selected.");
            return;
        }

        pst.executeBatch();
        conn.commit();

        JOptionPane.showMessageDialog(this, "Attendance saved successfully!");
        loadAttendanceTable();

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error saving attendance: " + ex.getMessage());
    }
}



    private void loadAttendanceTable() {
        DefaultTableModel model = (DefaultTableModel) jTable2.getModel();
        model.setRowCount(0);

        String sql = """
                SELECT a.attendance_id,
                       e.enrollment_id,
                       a.attendance_date,
                       s.full_name,
                       c.class_name,
                       a.status,
                       a.remarks
                FROM tbl_attendance a
                JOIN tbl_enrollments e ON a.enrollment_id = e.enrollment_id
                JOIN tbl_students s ON e.student_id = s.student_id
                JOIN tbl_classes c ON e.class_id = c.class_id
                ORDER BY a.attendance_date DESC
                """;

        try (Connection conn = AttendanceData.getConnection();
             Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("attendance_id"),
                    rs.getInt("enrollment_id"),
                    rs.getString("full_name"),
                    rs.getDate("attendance_date"),
                    rs.getString("status"),
                    rs.getString("remarks")
                });
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading records: " + ex.getMessage());
        }
    }

    private void initAttendanceTables() {
        // enrolled-students table (with checkbox)
        tblAttendance.setModel(new DefaultTableModel(
            new Object[][] {},
            new String[]{"EnrollmentID", "StudentID", "Student Name", "Mark"}
        ) {
            Class[] types = new Class[]{
                Integer.class, Integer.class, String.class, Boolean.class
            };

            @Override public Class getColumnClass(int columnIndex) {
                return types[columnIndex];
            }

            @Override public boolean isCellEditable(int row, int col) {
                return col == 3; // only checkbox editable
            }
        });

        // attendance history table
        jTable2.setModel(new DefaultTableModel(
            new Object[][] {},
            new String[]{"Attendance ID", "Enrollment ID", "Student Name", "Date", "Status", "Remarks"}
        ) {
            Class[] types = new Class[]{ Integer.class, Integer.class, String.class, java.sql.Date.class, String.class, String.class};
            @Override public Class getColumnClass(int columnIndex) { return types[columnIndex]; }
            @Override public boolean isCellEditable(int row, int col) { return false; }
        });
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cmbclass = new javax.swing.JComboBox<>();
        cmbStatus = new javax.swing.JComboBox<>();
        txtRemarks = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblAttendance = new javax.swing.JTable();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        dcAttendanceDate = new com.toedter.calendar.JDateChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("ATTENDANCE FORM");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Class : ");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Status : ");

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Remarks :");

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Attendance Date : ");

        cmbclass.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cmbclass.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbclassActionPerformed(evt);
            }
        });

        cmbStatus.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        cmbStatus.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Select Status", "Present", "Absent", "Excused", "Late" }));
        cmbStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmbStatusActionPerformed(evt);
            }
        });

        txtRemarks.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        txtRemarks.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtRemarksActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setText("Save Attendance");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton2.setText("Back");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        tblAttendance.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        tblAttendance.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Student ID", "Student Name", "Status"
            }
        ));
        jScrollPane2.setViewportView(tblAttendance);

        jTable2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Attendance_ID", "Enrollment_ID", "Student_Name", "Date", "Status", "Remarks"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane3.setViewportView(jTable2);

        dcAttendanceDate.addPropertyChangeListener(new java.beans.PropertyChangeListener() {
            public void propertyChange(java.beans.PropertyChangeEvent evt) {
                dcAttendanceDatePropertyChange(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 454, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jButton1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cmbclass, 0, 241, Short.MAX_VALUE)
                                    .addComponent(cmbStatus, 0, 241, Short.MAX_VALUE)
                                    .addComponent(txtRemarks)
                                    .addComponent(dcAttendanceDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jButton2))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 1033, Short.MAX_VALUE))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {cmbStatus, cmbclass, dcAttendanceDate, txtRemarks});

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cmbclass, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cmbStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, 36, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txtRemarks, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(dcAttendanceDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(32, 32, 32)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
            .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 737, Short.MAX_VALUE)
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {cmbStatus, cmbclass, dcAttendanceDate, jLabel1, jLabel2, jLabel4, jLabel5, txtRemarks});

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
Dashboard dash = new Dashboard(role);
    dash.setVisible(true);
    this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        saveAttendanceForSelectedStudents();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtRemarksActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtRemarksActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtRemarksActionPerformed

    private void cmbStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbStatusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmbStatusActionPerformed

    private void cmbclassActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmbclassActionPerformed
        int classId = parseClassIdFromCombo();
        if (classId > 0) loadEnrolledStudents(classId);
        else ((DefaultTableModel) tblAttendance.getModel()).setRowCount(0);
    }//GEN-LAST:event_cmbclassActionPerformed

    private void dcAttendanceDatePropertyChange(java.beans.PropertyChangeEvent evt) {//GEN-FIRST:event_dcAttendanceDatePropertyChange
if ("date".equals(evt.getPropertyName())) {
        java.util.Date d = dcAttendanceDate.getDate();
        System.out.println("Selected date: " + d);
    }
    }//GEN-LAST:event_dcAttendanceDatePropertyChange
public static void main(String args[]) {
        /* Set the Nimbus look and feel (auto-generated block) */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form for testing — pass a role explicitly */
        java.awt.EventQueue.invokeLater(() -> new AttendanceForm("Admin").setVisible(true)); // ADDED: pass role for testing
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> cmbStatus;
    private javax.swing.JComboBox<String> cmbclass;
    private com.toedter.calendar.JDateChooser dcAttendanceDate;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable tblAttendance;
    private javax.swing.JTextField txtRemarks;
    // End of variables declaration//GEN-END:variables
}
