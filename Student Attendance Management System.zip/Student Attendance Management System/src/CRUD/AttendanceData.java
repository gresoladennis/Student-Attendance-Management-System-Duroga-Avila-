package CRUD;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AttendanceData {

    private static final String URL = "jdbc:mysql://localhost/attendance_db";
    private static final String USER = "root";
    private static final String PASS = "";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    

    // ======================
    // MODEL
    // ======================
    public static class AttendanceModel {
        private int attendanceId;
        private int enrollmentId;
        private String date;
        private String status;
        private String remarks;

        public int getAttendanceId() { return attendanceId; }
        public void setAttendanceId(int id) { this.attendanceId = id; }

        public int getEnrollmentId() { return enrollmentId; }
        public void setEnrollmentId(int id) { this.enrollmentId = id; }

        public String getDate() { return date; }
        public void setDate(String d) { this.date = d; }

        public String getStatus() { return status; }
        public void setStatus(String s) { this.status = s; }

        public String getRemarks() { return remarks; }
        public void setRemarks(String r) { this.remarks = r; }
    }


    // ======================
    // DAO (CRUD)
    // ======================
    public static class AttendanceDAO {

        // CREATE
        public boolean addAttendance(AttendanceModel a) {
            String sql = "INSERT INTO tbl_attendance (attendance_id, attendance_date, status, remarks) VALUES (?, ?, ?, ?)";

            try (Connection conn = AttendanceData.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setInt(1, a.getAttendanceId());
                ps.setDate(2, java.sql.Date.valueOf(a.getDate()));
                ps.setString(3, a.getStatus());
                ps.setString(4, a.getRemarks());

                return ps.executeUpdate() > 0;

            } catch (SQLException e) {
                System.out.println("Error saving attendance: " + e.getMessage());
                return false;
            }
        }



        // READ
        public List<AttendanceModel> getAllAttendance() {
            List<AttendanceModel> list = new ArrayList<>();

            String sql = "SELECT * FROM tbl_attendance ORDER BY attendance_date DESC";

            try (Connection conn = AttendanceData.getConnection();
                 Statement st = conn.createStatement();
                 ResultSet rs = st.executeQuery(sql)) {

                while (rs.next()) {
                    AttendanceModel a = new AttendanceModel();

                    a.setAttendanceId(rs.getInt("attendance_id"));
                    a.setEnrollmentId(rs.getInt("enrollment_id"));
                    a.setDate(rs.getDate("attendance_date").toString());
                    a.setStatus(rs.getString("status"));
                    a.setRemarks(rs.getString("remarks"));

                    list.add(a);
                }

            } catch (SQLException e) {
                System.out.println("Error loading attendance: " + e.getMessage());
            }

            return list;
        }

        // UPDATE
        public boolean updateAttendance(AttendanceModel a) {
            String sql = "UPDATE tbl_attendance SET enrollment_id=?, attendance_date=?, status=?, remarks=? WHERE attendance_id=?";

            try (Connection conn = AttendanceData.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setInt(1, a.getEnrollmentId());
                ps.setDate(2, java.sql.Date.valueOf(a.getDate()));
                ps.setString(3, a.getStatus());
                ps.setString(4, a.getRemarks());
                ps.setInt(5, a.getAttendanceId());

                return ps.executeUpdate() > 0;

            } catch (SQLException e) {
                System.out.println("Update attendance error: " + e.getMessage());
                return false;
            }
        }

        // DELETE
        public boolean deleteAttendance(int id) {
            String sql = "DELETE FROM tbl_attendance WHERE attendance_id=?";

            try (Connection conn = AttendanceData.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setInt(1, id);
                return ps.executeUpdate() > 0;

            } catch (SQLException e) {
                System.out.println("Delete attendance error: " + e.getMessage());
                return false;
            }
        }
    }
}
