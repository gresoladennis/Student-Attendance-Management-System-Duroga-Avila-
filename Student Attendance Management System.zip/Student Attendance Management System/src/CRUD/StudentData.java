package CRUD;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

// =======================================================
// DB CONNECTION + MODEL + DAO IN ONE FILE
// =======================================================
public class StudentData {

    // =======================================
    // 1) DATABASE CONNECTION
    // =======================================
    private static final String URL = "jdbc:mysql://localhost:3306/attendance_db";  
    private static final String USER = "root";
    private static final String PASS = "";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    public static class Student {

        private int studentId;
        private String fullName;
        private String sex;
        private String contactNo;
        private String course;
        private String yearLevel;


        // Constructors
        public Student() {}

        public Student(int id, String name, String sex, String contactNo, String course, String yearLevel) {
            this.studentId = id;
            this.fullName = name;
            this.sex = sex;
            this.contactNo = contactNo;
            this.course = course;
            this.yearLevel = yearLevel;
        }

        // Getters & Setters
        public int getStudentId() { return studentId; }
        public void setStudentId(int id) { this.studentId = id; }

        public String getFullName() { return fullName; }
        public void setFullName(String name) { this.fullName = name; }

        public String getSex() { return sex; }
        public void setSex(String sex) { this.sex = sex; }

        public String getContactNo() { return contactNo; }
        public void setContactNo(String contactNo) { this.contactNo = contactNo; }

        public String getCourse() { return course; }
        public void setCourse(String course) { this.course = course; }

        public String getYearLevel() { return yearLevel; }
        public void setYearLevel(String yearLevel) { this.yearLevel = yearLevel; }
    }

    // =======================================
    // 3) STUDENT DAO (COMPLETE CRUD)
    // =======================================
    public static class StudentDAO {

        // CREATE (INSERT)
        public boolean addStudent(Student s) {
    String sql = "INSERT INTO tbl_students (full_name, sex, contact_no, course, year_level) VALUES (?, ?, ?, ?, ?)";

    try (Connection con = getConnection();
         PreparedStatement pst = con.prepareStatement(sql)) {
        pst.setString(1, s.getFullName());
        pst.setString(2, s.getSex());
        pst.setString(3, s.getContactNo());
        pst.setString(4, s.getCourse());
        pst.setString(5, s.getYearLevel());

        return pst.executeUpdate() > 0;

    } catch (Exception e) {
        System.out.println("Error inserting: " + e.getMessage());
        return false;
    }
}

    public List<Student> getAllStudents() {

    List<Student> list = new ArrayList<>();
    String sql = "SELECT student_id, full_name, sex, contact_no, course, year_level FROM tbl_students";

    try (Connection conn = getConnection();
         PreparedStatement pst = conn.prepareStatement(sql);
         ResultSet rs = pst.executeQuery()) {

        while (rs.next()) {
            Student s = new Student();
            s.setStudentId(rs.getInt("student_id"));
            s.setFullName(rs.getString("full_name"));
            s.setSex(rs.getString("sex"));
            s.setContactNo(rs.getString("contact_no"));
            s.setCourse(rs.getString("course"));
            s.setYearLevel(rs.getString("year_level"));
            list.add(s);
        }

    } catch (Exception e) {
        e.printStackTrace();
    }

    return list;
}

        // UPDATE
        public boolean updateStudent(Student s) {
    String sql = "UPDATE tbl_students SET full_name=?, sex=?, contact_no=?, course=?, year_level=? WHERE student_id=?";

    try (Connection conn = StudentData.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        ps.setString(1, s.getFullName());
        ps.setString(2, s.getSex());
        ps.setString(3, s.getContactNo());
        ps.setString(4, s.getCourse());
        ps.setString(5, s.getYearLevel());
        ps.setInt(6, s.getStudentId());

        return ps.executeUpdate() > 0;

    } catch (SQLException e) {
        System.out.println("Error updating: " + e.getMessage());
        return false;
    }
}

        // DELETE
    public static boolean deleteStudent(int studentId) {
    String sql = "DELETE FROM tbl_students WHERE student_id = ?";

    try (Connection conn = DriverManager.getConnection(URL, USER, PASS);
         PreparedStatement stmt = conn.prepareStatement(sql)) {

        stmt.setInt(1, studentId);

        return stmt.executeUpdate() > 0;

    } catch (SQLException e) {
        System.out.println("Error deleting: " + e.getMessage());
        return false;
    }
}
}
}
