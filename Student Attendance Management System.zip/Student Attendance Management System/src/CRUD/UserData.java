package CRUD;

import java.sql.*;
import java.util.ArrayList;

public class UserData {

    private static final String URL = "jdbc:mysql://localhost/attendance_db";
    private static final String USER = "root";
    private static final String PASS = "";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    // MODEL
    public static class UserModel {
        private int userId;
        private String username;
        private String password;
        private String role;

        public UserModel() {}

        public UserModel(int userId, String username, String password, String role) {
            this.userId = userId;
            this.username = username;
            this.password = password;
            this.role = role;
        }

        public int getUserId() { return userId; }
        public void setUserId(int id) { this.userId = id; }

        public String getUsername() { return username; }
        public void setUsername(String name) { this.username = name; }

        public String getPassword() { return password; }
        public void setPassword(String pass) { this.password = pass; }

        public String getRole() { return role; }
        public void setRole(String role) { this.role = role; }
    }

    // DAO (CRUD)
    public static class UserDAO {

        // CREATE
        public boolean addUser(UserModel u) {
            String sql = "INSERT INTO tbl_users (username, password, role) VALUES (?, ?, ?)";

            try (Connection conn = UserData.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, u.getUsername());
                ps.setString(2, u.getPassword());
                ps.setString(3, u.getRole());

                return ps.executeUpdate() > 0;

            } catch (SQLException e) {
                System.out.println("Add user error: " + e.getMessage());
                return false;
            }
        }

        // READ
        public ArrayList<UserModel> getAllUsers() {
            ArrayList<UserModel> list = new ArrayList<>();
            String sql = "SELECT * FROM tbl_users";

            try (Connection conn = UserData.getConnection();
                Statement st = conn.createStatement();
                ResultSet rs = st.executeQuery(sql)) {

                while (rs.next()) {
                    UserModel u = new UserModel(
                        rs.getInt("user_id"),
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("role")
                    );
                    list.add(u);
                }

            } catch (SQLException e) {
                System.out.println("Read user error: " + e.getMessage());
            }

            return list;
        }

        // UPDATE
        public boolean updateUser(UserModel u) {
            String sql = "UPDATE tbl_users SET username=?, password=?, role=? WHERE user_id=?";

            try (Connection conn = UserData.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, u.getUsername());
                ps.setString(2, u.getPassword());
                ps.setString(3, u.getRole());
                ps.setInt(4, u.getUserId());

                return ps.executeUpdate() > 0;

            } catch (SQLException e) {
                System.out.println("Update user error: " + e.getMessage());
                return false;
            }
        }

        // DELETE
        public boolean deleteUser(int id) {
            String sql = "DELETE FROM tbl_users WHERE user_id=?";

            try (Connection conn = UserData.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setInt(1, id);
                return ps.executeUpdate() > 0;

            } catch (SQLException e) {
                System.out.println("Delete user error: " + e.getMessage());
                return false;
            }
        }
    }
}
