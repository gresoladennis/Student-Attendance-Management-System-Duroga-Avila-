package CRUD;

import java.sql.*;
import java.util.ArrayList;

public class ClassData {

    private static final String URL = "jdbc:mysql://localhost/attendance_db";
    private static final String USER = "root";
    private static final String PASS = "";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    
    
    // ======================
    // MODEL
    // ======================
    public static class ClassModel {
        private int classId;
        private String className;
        private String schedule;
        private int teacherId;

        public ClassModel() {}

        public ClassModel(int classId, String className, String schedule, int teacherId) {
            this.classId = classId;
            this.className = className;
            this.schedule = schedule;
            this.teacherId = teacherId;
        }

        public int getClassId() { return classId; }
        public void setClassId(int id) { this.classId = id; }

        public String getClassName() { return className; }
        public void setClassName(String name) { this.className = name; }

        public String getSchedule() { return schedule; }
        public void setSchedule(String sched) { this.schedule = sched; }

        public int getTeacherId() { return teacherId; }
        public void setTeacherId(int tid) { this.teacherId = tid; }
    }

    // ======================
    // DAO (CRUD)
    // ======================
    public static class ClassDAO {

        // CREATE
        public boolean addClass(ClassModel c) {
            String sql = "INSERT INTO tbl_classes (class_name, schedule, teacher_id) VALUES (?, ?, ?)";

            try (Connection conn = ClassData.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, c.getClassName());
                ps.setString(2, c.getSchedule());
                ps.setInt(3, c.getTeacherId());

                return ps.executeUpdate() > 0;

            } catch (SQLException e) {
                System.out.println("Add class error: " + e.getMessage());
                return false;
            }
        }

        // READ
        public ArrayList<ClassModel> getAllClasses() {
            ArrayList<ClassModel> list = new ArrayList<>();
            String sql = "SELECT * FROM tbl_classes";

            try (Connection conn = ClassData.getConnection();
                Statement st = conn.createStatement();
                ResultSet rs = st.executeQuery(sql)) {

                while (rs.next()) {
                    ClassModel c = new ClassModel(
                        rs.getInt("class_id"),
                        rs.getString("class_name"),
                        rs.getString("schedule"),
                        rs.getInt("teacher_id")
                    );
                    list.add(c);
                }

            } catch (SQLException e) {
                System.out.println("Read class error: " + e.getMessage());
            }

            return list;
        }

        // UPDATE
        public boolean updateClass(ClassModel c) {
            String sql = "UPDATE tbl_classes SET class_name=?, schedule=?, teacher_id=? WHERE class_id=?";

            try (Connection conn = ClassData.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setString(1, c.getClassName());
                ps.setString(2, c.getSchedule());
                ps.setInt(3, c.getTeacherId());
                ps.setInt(4, c.getClassId());

                return ps.executeUpdate() > 0;

            } catch (SQLException e) {
                System.out.println("Update class error: " + e.getMessage());
                return false;
            }
        }

        // DELETE
        public boolean deleteClass(int id) {
            String sql = "DELETE FROM tbl_classes WHERE class_id=?";

            try (Connection conn = ClassData.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setInt(1, id);
                return ps.executeUpdate() > 0;

            } catch (SQLException e) {
                System.out.println("Delete class error: " + e.getMessage());
                return false;
            }
        }
    }
}
