package CRUD;

import java.sql.*;
import java.util.ArrayList;

public class EnrollmentData {

    // ======================
    // DATABASE CONNECTION
    // ======================
    private static final String URL = "jdbc:mysql://localhost/attendance_db";
    private static final String USER = "root";
    private static final String PASS = "";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASS);
    }

    // ======================
    // MODEL
    // ======================
    public static class EnrollmentModel {
        private int enrollmentId;
        private int studentId;
        private int classId;
        private String dateEnrolled;

        public EnrollmentModel() {}

        public EnrollmentModel(int enrollmentId, int studentId, int classId, String dateEnrolled) {
            this.enrollmentId = enrollmentId;
            this.studentId = studentId;
            this.classId = classId;
            this.dateEnrolled = dateEnrolled;
        }

        public int getEnrollmentId() { return enrollmentId; }
        public void setEnrollmentId(int id) { this.enrollmentId = id; }

        public int getStudentId() { return studentId; }
        public void setStudentId(int id) { this.studentId = id; }

        public int getClassId() { return classId; }
        public void setClassId(int id) { this.classId = id; }

        public String getDateEnrolled() { return dateEnrolled; }
        public void setDateEnrolled(String date) { this.dateEnrolled = date; }
    }

    // ======================
    // DAO (CRUD)
    // ======================
    public static class EnrollmentDAO {

        // CREATE
        public boolean addEnrollment(EnrollmentModel e) {
            String sql = "INSERT INTO tbl_enrollments (student_id, class_id, date_enrolled) VALUES (?, ?, ?)";

            try (Connection conn = EnrollmentData.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setInt(1, e.getStudentId());
                ps.setInt(2, e.getClassId());
                ps.setString(3, e.getDateEnrolled());

                return ps.executeUpdate() > 0;

            } catch (SQLException ex) {
                System.out.println("Add enrollment error: " + ex.getMessage());
                return false;
            }
        }

        // READ
        public ArrayList<EnrollmentModel> getAllEnrollments() {
            ArrayList<EnrollmentModel> list = new ArrayList<>();
            String sql = "SELECT * FROM tbl_enrollments";

            try (Connection conn = EnrollmentData.getConnection();
                Statement st = conn.createStatement();
                ResultSet rs = st.executeQuery(sql)) {

                while (rs.next()) {
                    EnrollmentModel e = new EnrollmentModel(
                        rs.getInt("enrollment_id"),
                        rs.getInt("student_id"),
                        rs.getInt("class_id"),
                        rs.getString("date_enrolled")
                    );
                    list.add(e);
                }

            } catch (SQLException ex) {
                System.out.println("Read enrollment error: " + ex.getMessage());
            }

            return list;
        }

        // UPDATE
        public boolean updateEnrollment(EnrollmentModel e) {
            String sql = "UPDATE tbl_enrollments SET student_id=?, class_id=?, date_enrolled=? WHERE enrollment_id=?";

            try (Connection conn = EnrollmentData.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setInt(1, e.getStudentId());
                ps.setInt(2, e.getClassId());
                ps.setString(3, e.getDateEnrolled());
                ps.setInt(4, e.getEnrollmentId());

                return ps.executeUpdate() > 0;

            } catch (SQLException ex) {
                System.out.println("Update enrollment error: " + ex.getMessage());
                return false;
            }
        }

        // DELETE
        public boolean deleteEnrollment(int id) {
            String sql = "DELETE FROM tbl_enrollments WHERE enrollment_id=?";

            try (Connection conn = EnrollmentData.getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {

                ps.setInt(1, id);
                return ps.executeUpdate() > 0;

            } catch (SQLException ex) {
                System.out.println("Delete enrollment error: " + ex.getMessage());
                return false;
            }
        }
    }
}
